<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="paths" tilewidth="16" tileheight="16" tilecount="64" columns="4">
 <image source="paths.png" width="64" height="256"/>
</tileset>
