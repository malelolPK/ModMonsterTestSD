<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="mine_desert" tilewidth="16" tileheight="16" tilecount="384" columns="16">
 <image source="mine_desert.png" width="256" height="384"/>
</tileset>
